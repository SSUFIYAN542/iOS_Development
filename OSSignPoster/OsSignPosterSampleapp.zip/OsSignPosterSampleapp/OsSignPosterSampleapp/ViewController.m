//
//  ViewController.m
//  OsSignPosterSampleapp
//
//  Created by syed on 13/08/25.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
