//
//  AppDelegate.m
//  OsSignPosterSampleapp
//
//  Created by syed on 13/08/25.
//

#import "AppDelegate.h"
#import <os/log.h>
#import <os/signpost.h>

@interface AppDelegate ()
@end

@implementation AppDelegate

static OSSignposter *dataProcessingSignposter;

+ (void)initialize {
    if (self == [AppDelegate class]) {
        if (@available(iOS 16.0, *)) {
            dataProcessingSignposter = [[OSSignposter alloc] initWithSubsystem:@"com.example.SampleApp" category:@"DataProcessing"];
        }
    }
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    for (int i = 0; i < 3; i++) {
        NSLog(@"--- Starting instrumented task run #%d ---", i + 1);
        [self performInstrumentedTask];
    }
    NSLog(@"All tasks finished. Check Instruments for the 'OS Signpost' track.");
    return YES;
}

- (void)performInstrumentedTask {
    if (@available(iOS 16.0, *)) {
        OSSignposter *signposter = dataProcessingSignposter;
        if (!signposter) {
            NSLog(@"OSSignposter not initialized.");
            return;
        }
        NSLog(@"Starting instrumented task...");

        os_signpost_id_t signpostID = [signposter makeSignpostID];
        OSSignpostIntervalState *state = [signposter beginInterval:@"ProcessFile" signpostID:signpostID];

        // Simulated work, replace with actual workload.
        [NSThread sleepForTimeInterval:1.0];

        [signposter emitEvent:@"TaskMilestone" signpostID:signpostID];
        [signposter endInterval:@"ProcessFile" state:state];

        NSLog(@"Instrumented task finished.");
    } else {
        NSLog(@"OSSignposter is not available on this OS version.");
    }
}

@end
