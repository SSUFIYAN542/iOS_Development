//
//  SceneDelegate.h
//  OsSignPosterSampleapp
//
//  Created by syed on 13/08/25.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

